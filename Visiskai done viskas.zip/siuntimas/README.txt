Ši C programa sukuria HTML ir CSS kodą. Vartotojas gali pasirinkti kokį veidą nori sukurti, kad tas veidas po to atsirastų svetainėje.
Vartotojas renkasi tarp skirtingų bruožų ir taip formuoja savo pasirinktą veidą.

Šita c programa veikia tik su window operacinė sistema. Ir C programa turi būti tam pačiame aplanke, kuriame yra visi paveiksliukų aplankai.

Vartotojo sąsajos valdymas:
Vartotojas naudodamas rodykles eina per įvairius bruožus ir kai pasirenka, kurį nori bruožą, tai tada spaudžia kairės pusės rodyklę, kad sugrįžtų į pagrindinį langą.
Ir kai visus norimus bruožus pasirenka varotojas, tai jis paspaudęs kairės pusės rodyklę pagrindiniame lange, gali užbaigti visą savo pasirinkimą ir tada yra sukuriami HTML ir CSS failai.